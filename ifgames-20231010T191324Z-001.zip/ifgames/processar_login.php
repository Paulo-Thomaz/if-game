<?php
require_once "conexao.php";

// Recupere os dados do formulário
$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];

// Consulta SQL para verificar se o email está cadastrado
$sqlVerificarEmail = "SELECT * FROM usuario WHERE email = '$email'";
$resultEmail = $conn->query($sqlVerificarEmail);

if ($resultEmail->num_rows == 0) {
    // O email não está cadastrado, redirecionar para processar_login.php com erro
    header("Location: login.html?erro=1");
    exit();
} else {
    // O email está cadastrado, verifique a senha
    $sqlVerificarSenha = "SELECT * FROM usuario WHERE email = '$email' AND senha = '$senha'";
    $resultSenha = $conn->query($sqlVerificarSenha);

    if ($resultSenha->num_rows > 0) {
        // O email e a senha correspondem, redirecionar para cadastrar-usuario-sucesso.php
        header("Location: index.html");
        exit();
    } else {
        // A senha não corresponde, redirecionar para processar_login.php com erro
        header("Location: login.html?erro=2");
        exit();
    }
}

$conn->close();
?>
